package it.juke.launcher

import android.app.Activity
import android.os.Bundle
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.widget.*

class MainActivity : Activity() {
    private val bg = Color.rgb(5, 7, 11)
    private val red = Color.rgb(238, 35, 52)
    private val white = Color.rgb(242, 245, 250)
    private val muted = Color.rgb(170, 185, 202)
    // Scala automaticamente spazi e testi sui display più larghi (9 e 10,1 pollici).
    private val uiScale: Float by lazy {
        (resources.configuration.screenWidthDp / 900f).coerceIn(1.0f, 1.30f)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.decorView.systemUiVisibility = View.SYSTEM_UI_FLAG_FULLSCREEN or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
        buildDashboard()
    }

    private fun buildDashboard() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(10), dp(18), dp(12))
            setBackgroundColor(bg)
        }
        val header = LinearLayout(this).apply {
            gravity = Gravity.CENTER_VERTICAL
            orientation = LinearLayout.HORIZONTAL
        }
        header.addView(label("JUKE", 24f, white, true), LinearLayout.LayoutParams(0, dp(48), 1f))
        header.addView(label("N I S S A N", 18f, white, true))
        header.addView(label("   ●  Bluetooth   ▮▮  Wi-Fi   ", 12f, muted, false))
        header.addView(label(java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date()), 19f, white, true))
        root.addView(header)

        val line = View(this).apply { setBackgroundColor(red) }
        root.addView(line, LinearLayout.LayoutParams(-1, dp(2)))

        val cards = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            setPadding(0, dp(12), 0, dp(12))
        }
        cards.addView(card("➤", "Navigazione", "Apri Maps o Waze", "maps"), weightParams(1f))
        cards.addView(card("♫", "Musica", "Le tue app audio", "music"), weightParams(1f))
        cards.addView(card("☎", "Telefono", "Bluetooth e chiamate", "phone"), weightParams(1f))
        cards.addView(carCard(), weightParams(1.25f))
        root.addView(cards, LinearLayout.LayoutParams(-1, 0, 1f))

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = rounded(Color.rgb(12, 16, 23), Color.rgb(40, 49, 62), 14)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val apps = listOf(
            Triple("▦", "Tutte le app", "all"),
            Triple("▶", "YouTube", "youtube"),
            Triple("♫", "Spotify", "spotify"),
            Triple("🌐", "Chrome", "chrome"),
            Triple("⚙", "Impostazioni", "settings")
        )
        apps.forEach { (icon, title, key) ->
            val item = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                setPadding(dp(4), dp(5), dp(4), dp(5))
                setOnClickListener { launch(key) }
            }
            item.addView(label(icon, 25f, if (key == "all") red else white, true))
            item.addView(label(title, 11f, muted, false))
            dock.addView(item, LinearLayout.LayoutParams(0, -2, 1f))
        }
        root.addView(dock, LinearLayout.LayoutParams(-1, dp(68)))
        setContentView(root)
    }

    private fun card(icon: String, title: String, subtitle: String, action: String): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(10), dp(8), dp(10))
            background = rounded(Color.rgb(12, 17, 25), Color.rgb(52, 65, 82), 16)
            setOnClickListener { launch(action) }
        }
        box.addView(label(icon, 34f, red, true))
        box.addView(label(title, 17f, white, true))
        box.addView(label(subtitle, 11f, muted, false))
        return box
    }

    private fun carCard(): View {
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(8), dp(8), dp(8), dp(8))
            background = rounded(Color.rgb(15, 15, 20), Color.rgb(80, 42, 48), 16)
            setOnClickListener { launch("settings") }
        }
        box.addView(label("LA TUA NISSAN", 15f, white, true))
        box.addView(label("JUKE F15 · BOSE EDITION", 11f, muted, false))
        box.addView(label("◢  WHITE  JUKE  ◣", 22f, white, true))
        box.addView(label("2018  •  CERCHI NERI", 11f, red, true))
        box.addView(label("Info auto · Impostazioni", 11f, muted, false))
        return box
    }

    private fun launch(key: String) {
        if (key == "all") {
            startActivity(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER))
            return
        }
        if (key == "settings") {
            try { startActivity(Intent(android.provider.Settings.ACTION_SETTINGS)); return } catch (_: Exception) {}
        }
        val packages = when (key) {
            "maps" -> listOf("com.google.android.apps.maps", "com.waze")
            "music" -> listOf("com.spotify.music", "com.google.android.youtube.music", "com.google.android.music")
            "youtube" -> listOf("com.google.android.youtube")
            "spotify" -> listOf("com.spotify.music")
            "chrome" -> listOf("com.android.chrome")
            "phone" -> listOf("com.android.bluetooth", "com.google.android.dialer")
            else -> emptyList()
        }
        for (pkg in packages) {
            val intent = packageManager.getLaunchIntentForPackage(pkg)
            if (intent != null) { startActivity(intent); return }
        }
        Toast.makeText(this, "App non trovata: verifica che sia installata sullo stereo.", Toast.LENGTH_LONG).show()
    }

    private fun label(text: String, size: Float, color: Int, bold: Boolean): TextView =
        TextView(this).apply {
            this.text = text
            textSize = size * uiScale
            setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) setTypeface(typeface, Typeface.BOLD)
            setPadding(dp(3), dp(4), dp(3), dp(4))
        }

    private fun rounded(color: Int, stroke: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1), stroke)
    }

    private fun weightParams(weight: Float) = LinearLayout.LayoutParams(0, -1, weight).apply {
        setMargins(dp(4), 0, dp(4), 0)
    }

    private fun dp(value: Int): Int = (value * uiScale * resources.displayMetrics.density).toInt()
}
