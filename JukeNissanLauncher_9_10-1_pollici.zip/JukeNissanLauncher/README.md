# Juke Nissan Launcher — progetto Android

Progetto iniziale Android Studio per un launcher orizzontale ispirato alla Nissan Juke F15 BOSE Edition 2018. L’interfaccia si adatta automaticamente a schermi da 7, 9 e 10,1 pollici: sui display più larghi aumenta gradualmente la dimensione di testi e spaziature.

## Generare l'APK usando solo il telefono (GitHub Actions)
1. Scarica questo ZIP e decomprimilo sul telefono.
2. Nel browser vai su GitHub e crea un nuovo repository vuoto chiamato `JukeNissanLauncher`.
3. Carica tutti i file e le cartelle del progetto nel repository, mantenendo anche `.github/workflows/build.yml`.
4. Apri la scheda **Actions** del repository e abilita le Actions se richiesto.
5. Avvia **Build Android APK** con **Run workflow** (oppure attendi che finisca il workflow avviato dal push).
6. Apri la corsa completata e scarica l'artifact `JukeNissanLauncher-debug-apk`. Estrai l'APK dall'archivio scaricato.
7. Trasferisci `app-debug.apk` sullo stereo e installalo. Per impostarlo come Home, premi il tasto Home e seleziona il launcher se Android mostra la scelta.

Nota: GitHub potrebbe richiedere conferma dell'account e le impostazioni di Actions possono cambiare. Non pubblicare chiavi o password. Il repository può essere privato.

## Compilazione con Android Studio
Apri la cartella del progetto in Android Studio e usa **Build > Build APK(s)**.

## Limiti
- Questo ZIP contiene codice sorgente, non un APK già compilato.
- Il progetto è una base iniziale; la compatibilità va verificata sul firmware specifico dello stereo.
- I pulsanti aprono app comuni se presenti; le funzioni OEM, BOSE e telecamera 360° dipendono dalle app e dalle integrazioni originali dello stereo.
- L'auto è rappresentata da un'etichetta grafica, non da un modello 3D fotorealistico.
